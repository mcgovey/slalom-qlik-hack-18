export default {
  // host: 'sense-demo.qlik.com',
  host: 'slalomny.hopto.org',
  secure: true,
  port: 443,
  prefix: '',
  // appId: '372cbc85-f7fb-4db6-a620-9a5367845dce',
  appId: '2acadc29-2945-4404-ba28-003e0fa7f55a',
};
