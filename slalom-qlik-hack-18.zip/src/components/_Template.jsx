import React from 'react';

const Template = () => (
  <div className="container">

  </div>
);

export default Template;
